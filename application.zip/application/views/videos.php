
<link rel="stylesheet" href="<?php echo base_url('css/video_style.css')?>"></link>





<section class="content" style="margin-top: 50px;padding: 0;">

    <div class="p-t-0 m-b-15" style="background: #fff">
        <div class="contest-cat-line " style="border-bottom: 1px dotted #fff;padding-top: 10px">
            <div class="col-sm-8 col-sm-offset-2">
               <!-- <ul>
                    <li class="label label-danger"><a href=""> Explore All</a> </li>
                    <li class="label label-success hidden-xs"><a href=""> Discover </a> </li>
                    <li class="label label-warning hidden-xs"><a href=""> New </a> </li>
                    <li class="label bg-aqua-gradient hidden-xs"><a href=""> Action </a> </li>
                    <li class="label bg-purple hidden-xs"><a href=""> Winner </a> </li>
                    <li class="label bg-teal-gradient hidden-xs"><a href=""> City </a> </li>


                    <li class="label label-primary pull-right dropdown" style="margin-right: -10px"><a href="" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> Categories ▾ </a>

                        <ul class="dropdown-menu no-border-radius" role="menu" aria-labelledby="dLabel" style="width: 300px;height: 400px">

                            <div class="row">
                                <div class="dropLinks">
                                    <ul class="" style="color: #000;">
                                        <li><a href="" class="default" style="color: #000;">Prize Value</a></li>
                                        <li><a href="" class="">Closing Soon</a></li>
                                        <li><a href="" class="">Winners</a></li>
                                        <li><a href="" class="">Jury</a></li>
                                        <li><a href="" class="">Abstract</a></li>
                                        <li><a href="" class="">Action</a></li>
                                        <li><a href="" class="">Animals</a></li>
                                        <li><a href="" class="">Architecture</a></li>
                                        <li><a href="" class="">Black &amp; White</a></li>
                                        <li><a href="" class="">Colors</a></li>
                                        <li><a href="" class="">City</a></li>
                                        <li><a href="" class="">Fashion</a></li>
                                        <li><a href="" class="">Fine Nudes</a></li>
                                        <li><a href="" class="">Food</a></li>
                                        <li><a href="" class="">Landscapes</a></li>
                                        <li><a href="" class="">Manipulations</a></li>
                                        <li><a href="" class="">Nature</a></li>
                                        <li><a href="" class="">Night</a></li>
                                        <li><a href="" class="">Objects</a></li>
                                        <li><a href="" class="">People</a></li>
                                        <li><a href="" class="">Transportation</a></li>
                                        <li><a href="" class="">Water</a></li>
                                    </ul>
                                </div>
                            </div>
                        </ul>
                    </li>
                </ul>-->
            </div>
        </div>
    </div>

    <div class="container-fluid p-0 m-20" style="min-height: 650px;">


<!--        <h2 class="text-center f-raleway"><i class="fa fa-video"></i> <br> Working in Progress <br> ............................ </h2>-->

        <div class="col-sm-2">


        </div>
        <div class="col-sm-10" id="list">

            <div class="videoItem">
                <p class="category">Category</p>
                <a href="#" class="thumbnail">
                    <span class="duration">05:00</span>
                    <img src="https://s1.dmcdn.net/IDEz8.jpg">
                    <div class="play"></div>
                </a>
                <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa dui, ornare eu porttitor ut, tristique ac tellus.</a></p>
                <p class="author"><a href="#">Author</a></p>
            </div>

            <div class="videoItem">
                <p class="category">Category</p>
                <a href="#" class="thumbnail">
                    <img src="https://s1.dmcdn.net/IDEz8.jpg">
                    <div class="play"></div>
                    <span class="duration">05:00</span>
                </a>
                <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa dui, ornare eu porttitor ut, tristique ac tellus.</a></p>
                <p class="author"><a href="#">Author</a></p>
            </div>

            <div class="videoItem">
                <p class="category promoted">Promoted</p>
                <a href="#" class="thumbnail">
                    <img src="https://s1.dmcdn.net/IDEz8.jpg">
                    <div class="play"></div>
                    <span class="duration">05:00</span>
                </a>
                <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa dui, ornare eu porttitor ut, tristique ac tellus.</a></p>
                <p class="author"><a href="#">Author</a></p>
            </div>

            <div class="videoItem">
                <p class="category">Category</p>
                <a href="#" class="thumbnail">
                    <img src="https://s1.dmcdn.net/IDEz8.jpg">
                    <div class="play"></div>
                    <span class="duration">05:00</span>
                </a>
                <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa dui, ornare eu porttitor ut, tristique ac tellus.</a></p>
                <p class="author"><a href="#">Author</a></p>
            </div>

            <div class="videoItem">
                <p class="category">Category</p>
                <a href="#" class="thumbnail">
                    <img src="https://s1.dmcdn.net/IDEz8.jpg">
                    <div class="play"></div>
                    <span class="duration">05:00</span>
                </a>
                <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa dui, ornare eu porttitor ut, tristique ac tellus.</a></p>
                <p class="author"><a href="#">Author</a></p>
            </div>

            <div class="videoItem">
                <p class="category">Category</p>
                <a href="#" class="thumbnail">
                    <img src="https://s1.dmcdn.net/IDEz8.jpg">
                    <div class="play"></div>
                    <span class="duration">05:00</span>
                </a>
                <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa dui, ornare eu porttitor ut, tristique ac tellus.</a></p>
                <p class="author"><a href="#">Author</a></p>
            </div>

        </div>


    </div>




</section>
